export const environment = {
  apiUrl: 'http://backend-feos.test/api'
};