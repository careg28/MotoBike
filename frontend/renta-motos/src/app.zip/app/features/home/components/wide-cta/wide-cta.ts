import { Component, EventEmitter, Output } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-wide-cta',
  imports: [TranslateModule],
  templateUrl: './wide-cta.html',
  styleUrl: './wide-cta.scss'
})
export class WideCta {
  @Output() reserveClicked = new EventEmitter<void>();
  onReserve() { this.reserveClicked.emit(); }
}
