import { Component } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-hero-header',
  imports: [TranslateModule],
  templateUrl: './hero-header.html',
  styleUrl: './hero-header.scss'
})
export class HeroHeader {

}
