<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reserva;
use Illuminate\Http\Request;

class ReservaController extends Controller
{
    // GET /api/reservas?search=&estado=&modelo_id=&per_page=10
    public function index(Request $req)
    {
        $perPage = $req->input('per_page', 10);

        $q = Reserva::query()
            ->with(['modelo', 'moto'])
            ->buscar($req->input('search'))
            ->estado($req->input('estado'))
            ->delModelo($req->input('modelo_id'))
            ->latest();

        if ($perPage === 'all' || (int)$perPage === -1) {
            return response()->json(['data' => $q->get()]);
        }

        return $q->paginate((int)$perPage);
    }

    // GET /api/reservas/{reserva}
    public function show(Reserva $reserva)
    {
        return $reserva->load(['modelo', 'moto']);
    }

    // POST /api/reservas  (crea booking en HOLD; el pago vendrá después)
    public function store(Request $req)
    {
        $data = $req->validate([
            'modelo_id'      => ['required', 'exists:modelos,id'],
            'fecha_inicio'   => ['required', 'date'],
            'fecha_fin'      => ['required', 'date', 'after:fecha_inicio'],

            'precio_total'   => ['required', 'numeric', 'min:0'],
            'deposito'       => ['nullable', 'numeric', 'min:0'],
            'moneda'         => ['required', 'size:3'],

            'cliente_nombre' => ['required', 'string', 'max:255'],
            'cliente_email'  => ['required', 'email', 'max:255'],
            'cliente_tel'    => ['nullable', 'string', 'max:50'],

            'notas'          => ['nullable', 'string'],
        ]);

        // TODO: check disponibilidad aquí (siguiente paso del flujo)
        $data['estado'] = Reserva::ESTADO_HOLD;

        $reserva = Reserva::create($data);

        return response()->json($reserva->load(['modelo', 'moto']), 201);
    }

    // PATCH /api/reservas/{reserva}
    public function update(Request $req, Reserva $reserva)
    {
        $data = $req->validate([
            'estado'            => ['sometimes', 'in:hold,paid,assigned,canceled,expired'],
            'moto_id'           => ['nullable', 'exists:motos,id'],
            'payment_intent_id' => ['nullable', 'string', 'max:255'],
            'payment_status'    => ['nullable', 'string', 'max:255'],
            'notas'             => ['nullable', 'string'],
        ]);

        $reserva->fill($data)->save();

        return response()->json($reserva->load(['modelo', 'moto']));
    }

    // DELETE /api/reservas/{reserva}
    public function destroy(Reserva $reserva)
    {
        $reserva->delete();
        return response()->noContent();
    }
}