<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up(): void
    {
        Schema::create('reservas', function (Blueprint $table) {
            $table->id();

            $table->foreignId('moto_id')->constrained('motos')->cascadeOnUpdate()->restrictOnDelete();
            $table->foreignId('cliente_id')->constrained('clientes')->cascadeOnUpdate()->restrictOnDelete();

            $table->dateTime('inicio');
            $table->dateTime('fin');

            $table->string('recogida_ubicacion')->nullable();
            $table->string('devolucion_ubicacion')->nullable();

            $table->enum('estado', ['pendiente','confirmada','recogida','devuelta','cancelada','no_show'])
                  ->default('pendiente');

            $table->decimal('precio_total', 10, 2)->default(0);
            $table->decimal('deposito', 10, 2)->default(0);

            $table->enum('pago_estado', ['sin_pagar','pagado','reembolsado','parcial'])
                  ->default('sin_pagar');

            $table->enum('canal', ['web','whatsapp','telefono','mostrador'])->default('web');

            $table->string('referencia')->unique(); // código reserva 
            $table->text('notas')->nullable();

            $table->timestamps();
            $table->softDeletes();

            // Índices útiles para búsquedas y disponibilidad
            $table->index(['moto_id', 'inicio', 'fin']);
            $table->index(['estado', 'pago_estado']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reservas');
    }
};